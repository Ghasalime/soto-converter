=== Soto WebP Converter ===
Contributors: soto-team
Tags: webp, optimization, images
Requires at least: 5.0
Tested up to: 6.4
Stable tag: 2.1.0
License: GPLv2 or later

Automatically convert all your WordPress media uploads to optimized WebP format.
