<?php
/**
 * Plugin Name: Soto Image Converter PRO
 * Plugin URI:  https://soto.web.id
 * Description: Optimasi gambar gila-gilaan ke format WebP & AVIF. Dilengkapi dashboard analitik visual dan kompresi bulk yang aman.
 * Version:     4.0.0
 * Author:      Soto Converter
 * Author URI:  https://soto.web.id
 * License:     GPL-2.0+
 * Text Domain: soto-image
 */

if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * 1. Inisialisasi Settings
 */
function soto_img_init_settings() {
    $defaults = array(
        'soto_img_enabled' => '1',
        'soto_img_quality' => 85,
        'soto_img_keep_original' => '0',
        'soto_img_resize_enabled' => '0',
        'soto_img_resize_max_width' => 1920,
        'soto_img_target_format' => 'webp',
        'soto_img_total_converted' => 0,
        'soto_img_total_saved_bytes' => 0,
    );
    foreach ( $defaults as $option => $value ) {
        register_setting( 'soto_img_settings', $option );
        if ( false === get_option( $option ) ) {
            update_option( $option, $value );
        }
    }
}
add_action( 'admin_init', 'soto_img_init_settings' );

function soto_img_format_bytes( $bytes, $precision = 2 ) {
    $units = array( 'B', 'KB', 'MB', 'GB', 'TB' );
    $bytes = max( $bytes, 0 );
    $pow = floor( ( $bytes ? log( $bytes ) : 0 ) / log( 1024 ) );
    $pow = min( $pow, count( $units ) - 1 );
    $bytes /= pow( 1024, $pow );
    return round( $bytes, $precision ) . ' ' . $units[ $pow ];
}

/**
 * 2. Menu Admin & Dashboard
 */
function soto_img_admin_menu() {
    $page = add_menu_page( 'Soto Converter', 'Soto Converter', 'manage_options', 'soto-img', 'soto_img_render_dashboard', 'dashicons-chart-pie', 80 );
    add_action( 'admin_print_scripts-' . $page, 'soto_img_admin_scripts' );
}
add_action( 'admin_menu', 'soto_img_admin_menu' );

function soto_img_admin_scripts() {
    wp_enqueue_script( 'jquery' );
    wp_enqueue_script( 'chart-js', 'https://cdn.jsdelivr.net/npm/chart.js', array(), '4.0', true );
}

function soto_img_render_dashboard() {
    // Save Settings
    if ( isset( $_POST['soto_img_save_settings'] ) && check_admin_referer( 'soto_img_save', 'soto_img_nonce' ) ) {
        update_option( 'soto_img_enabled', isset( $_POST['soto_img_enabled'] ) ? '1' : '0' );
        update_option( 'soto_img_keep_original', isset( $_POST['soto_img_keep_original'] ) ? '1' : '0' );
        update_option( 'soto_img_resize_enabled', isset( $_POST['soto_img_resize_enabled'] ) ? '1' : '0' );
        update_option( 'soto_img_quality', intval( $_POST['soto_img_quality'] ) );
        update_option( 'soto_img_resize_max_width', intval( $_POST['soto_img_resize_max_width'] ) );
        
        $selected_format = isset( $_POST['soto_img_target_format'] ) && $_POST['soto_img_target_format'] === 'avif' ? 'avif' : 'webp';
        update_option( 'soto_img_target_format', $selected_format );
        
        echo '<div class="updated"><p>Pengaturan berhasil disimpan!</p></div>';
    }

    $is_enabled = get_option( 'soto_img_enabled' ) == '1';
    $keep_original = get_option( 'soto_img_keep_original' ) == '1';
    $resize_enabled = get_option( 'soto_img_resize_enabled' ) == '1';
    $quality = get_option( 'soto_img_quality', 85 );
    $max_width = get_option( 'soto_img_resize_max_width', 1920 );
    $target_format = get_option( 'soto_img_target_format', 'webp' );
    
    $total_files = get_option( 'soto_img_total_converted', 0 );
    $saved_bytes = get_option( 'soto_img_total_saved_bytes', 0 );
    
    // Status server AVIF Support
    $avif_supported = function_exists('wp_image_editor_supports') && wp_image_editor_supports( array( 'mime_type' => 'image/avif' ) );

    // Hitung Library Stats
    $mime_counts = wp_count_attachments();
    $total_jpg = isset($mime_counts->{'image/jpeg'}) ? (int) $mime_counts->{'image/jpeg'} : 0;
    $total_png = isset($mime_counts->{'image/png'}) ? (int) $mime_counts->{'image/png'} : 0;
    $total_webp = isset($mime_counts->{'image/webp'}) ? (int) $mime_counts->{'image/webp'} : 0;
    $total_avif = isset($mime_counts->{'image/avif'}) ? (int) $mime_counts->{'image/avif'} : 0;

    $unoptimized = $total_jpg + $total_png;
    $optimized = $total_webp + $total_avif;
    $grand_total = $unoptimized + $optimized;
    $progress_ratio = $grand_total > 0 ? round(($optimized / $grand_total) * 100) : 0;

    ?>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap');
        .soto-wrap { margin: 20px 20px 0 0; font-family: 'Inter', system-ui, -apple-system, sans-serif; color: #1e293b; }
        .soto-header { background: linear-gradient(135deg, #10b981 0%, #059669 100%); padding: 35px; border-radius: 16px; color: white; display: flex; align-items: center; justify-content: space-between; box-shadow: 0 10px 25px rgba(16, 185, 129, 0.2); margin-bottom: 24px; position: relative; overflow: hidden; }
        .soto-header::before { content: ''; position: absolute; top: -50%; left: -50%; width: 200%; height: 200%; background: radial-gradient(circle, rgba(255,255,255,0.1) 0%, transparent 60%); transform: rotate(30deg); pointer-events: none; }
        .soto-header h1 { color: white; margin: 0; font-weight: 800; font-size: 2.5em; line-height: 1.2; letter-spacing: -1px; text-shadow: 0 2px 4px rgba(0,0,0,0.1); }
        .soto-header p { font-size: 1.1em; opacity: 0.95; margin: 5px 0 0 0; font-weight: 500; }
        .header-badge { background: rgba(255,255,255,0.25); padding: 5px 15px; border-radius: 50px; font-weight: 800; font-size: 13px; backdrop-filter: blur(5px); border: 1px solid rgba(255,255,255,0.2); text-transform: uppercase; letter-spacing: 1px; }
        .btn-visit { background: white; color: #059669; text-decoration: none; padding: 8px 18px; border-radius: 50px; font-weight: 700; font-size: 13px; box-shadow: 0 4px 10px rgba(0,0,0,0.15); transition: all 0.2s; display: inline-flex; align-items: center; gap: 6px; }
        .btn-visit:hover { transform: translateY(-2px); box-shadow: 0 6px 15px rgba(0,0,0,0.2); color: #10b981; }
        
        .soto-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 24px; margin-bottom: 24px; }
        .soto-card { background: white; padding: 25px; border-radius: 16px; border: 1px solid #e2e8f0; position: relative; overflow: hidden; box-shadow: 0 4px 6px rgba(0,0,0,0.02); }
        .soto-card h3 { margin: 0 0 10px 0; color: #64748b; font-size: 0.85em; text-transform: uppercase; font-weight: 700; letter-spacing: 0.5px; }
        .soto-card .val { font-size: 2.2em; font-weight: 800; color: #0f172a; }
        
        .soto-columns { display: grid; grid-template-columns: 2fr 1.5fr; gap: 24px; margin-bottom: 24px; }
        .soto-panel { background: white; border-radius: 16px; border: 1px solid #e2e8f0; padding: 30px; box-shadow: 0 4px 6px rgba(0,0,0,0.02); }
        .soto-panel-full { grid-column: 1 / -1; }
        .soto-panel h2 { font-size: 1.2em; margin-top: 0; padding-bottom: 15px; margin-bottom: 20px; border-bottom: 2px solid #f1f5f9; color: #0f172a; font-weight: 700; }
        
        .form-row { margin-bottom: 20px; display: flex; align-items: flex-start; flex-direction: column; gap: 8px; }
        .form-row label { font-weight: 600; font-size: 14px; color: #334155; }
        .form-row.horizontal { flex-direction: row; align-items: center; justify-content: space-between; }
        .form-desc { font-size: 12px; color: #64748b; margin-top: 2px; line-height: 1.4; font-weight: 400; }
        
        input[type=number], select { padding: 8px 12px; border-radius: 8px; border: 1px solid #cbd5e1; outline: none; transition: border 0.3s; }
        input[type=number]:focus, select:focus { border-color: #10b981; box-shadow: 0 0 0 3px rgba(16,185,129,0.1); }
        input[type=range] { width: 100%; accent-color: #10b981; }
        
        button.btn-primary { background: #10b981; color: #fff; border: none; padding: 12px 24px; border-radius: 8px; cursor: pointer; font-weight: 600; font-size: 14px; transition: all 0.3s; box-shadow: 0 4px 6px rgba(16,185,129,0.2); }
        button.btn-primary:hover { background: #059669; transform: translateY(-1px); }
        button.btn-primary:disabled { background: #94a3b8; cursor: not-allowed; transform: none; box-shadow: none; }
        
        .toggle-switch { display: flex; align-items: center; gap: 10px; cursor: pointer; }
        
        .chart-container { position: relative; height: 250px; width: 100%; display: flex; justify-content: center; }
        .stat-legend { display: flex; justify-content: space-around; margin-top: 20px; font-size: 13px; font-weight: 600; }
        .dot { display: inline-block; width: 10px; height: 10px; border-radius: 50%; margin-right: 5px; }

        .progress-box { margin-top: 20px; background: #e2e8f0; border-radius: 10px; overflow: hidden; height: 24px; box-shadow: inset 0 2px 4px rgba(0,0,0,0.05); }
        .progress-bar { background: linear-gradient(90deg, #10b981, #34d399); height: 100%; width: 0%; transition: width 0.3s ease-out; position: relative; }
        .progress-bar::after { content: ''; position: absolute; top: 0; left: 0; bottom: 0; right: 0; background: linear-gradient(45deg, rgba(255,255,255,0.2) 25%, transparent 25%, transparent 50%, rgba(255,255,255,0.2) 50%, rgba(255,255,255,0.2) 75%, transparent 75%, transparent); background-size: 20px 20px; animation: move 1s linear infinite; }
        @keyframes move { 0% { background-position: 0 0; } 100% { background-position: 20px 20px; } }
        
        .log-box { display:none; max-height: 200px; overflow-y: auto; background:#f8fafc; padding:15px; font-family:'Menlo', 'Consolas', monospace; font-size:12px; margin-top:20px; border-radius:8px; border:1px solid #cbd5e1; color: #334155; }
    </style>

    <div class="soto-wrap">
        <div class="soto-header">
            <div style="position: relative; z-index: 1;">
                <h1>Soto Image PRO</h1>
                <p>Mengonversi Library Website Anda Sekelas Enterprise.</p>
            </div>
            <div style="position: relative; z-index: 1; display:flex; flex-direction:column; align-items:flex-end; gap:12px;">
                <span class="header-badge"><?php echo $is_enabled ? '🟢 SYSTEM ACTIVE' : '⏸ SYSTEM PAUSED'; ?></span>
                <a href="https://soto.web.id" target="_blank" class="btn-visit">
                    <span class="dashicons dashicons-external" style="width: auto; height: auto; font-size: 14px;"></span> Kunjungi soto.web.id
                </a>
            </div>
        </div>

        <div class="soto-grid">
            <div class="soto-card">
                <h3>Images Dikonversi</h3>
                <div class="val"><?php echo esc_html( number_format( $total_files ) ); ?></div>
            </div>
            <div class="soto-card">
                <h3>Storage Diselamatkan</h3>
                <div class="val" style="color:#10b981;"><?php echo esc_html( soto_img_format_bytes( $saved_bytes ) ); ?></div>
            </div>
            <div class="soto-card">
                <h3>Skor Optimasi Library</h3>
                <div class="val"><?php echo $progress_ratio; ?>%</div>
            </div>
        </div>

        <div class="soto-columns">
            <!-- Settings Panel -->
            <div class="soto-panel">
                <h2>⚙️ Engine Configuration</h2>
                <form method="post">
                    <?php wp_nonce_field( 'soto_img_save', 'soto_img_nonce' ); ?>
                    
                    <div class="form-row horizontal">
                        <div>
                            <label>Aktifkan Autopilot Uploads</label>
                            <span class="form-desc" style="display:block;">Otomatis convert setiap user mengupload gambar baru ke Media.</span>
                        </div>
                        <input type="checkbox" name="soto_img_enabled" value="1" <?php checked( $is_enabled ); ?>>
                    </div>
                    
                    <div class="form-row">
                        <label>Format Generasi Berikutnya (Target Format)</label>
                        <select name="soto_img_target_format" style="width:100%;">
                            <option value="webp" <?php selected($target_format, 'webp'); ?>>WEBP (Support 99% Browser. Sangat Stabil)</option>
                            <?php if ($avif_supported) : ?>
                                <option value="avif" <?php selected($target_format, 'avif'); ?>>AVIF (Ukuran 30% Lebih Kecil. Butuh Server Kuat)</option>
                            <?php else : ?>
                                <option disabled>AVIF (Server Anda tidak support AVIF Imagick/GD)</option>
                            <?php endif; ?>
                        </select>
                    </div>

                    <div class="form-row">
                        <label>
                            Agresivitas Kompresi (<?php echo esc_html( $quality ); ?>%)
                        </label>
                        <div style="display:flex; width:100%; align-items:center; gap:15px;">
                            <input type="range" name="soto_img_quality" min="10" max="100" value="<?php echo esc_attr( $quality ); ?>" oninput="this.nextElementSibling.innerText = this.value + '%'">
                            <span style="font-weight:bold; min-width: 40px;"><?php echo esc_html( $quality ); ?>%</span>
                        </div>
                        <span class="form-desc">Makin kecil persentase, gambar makin kecil tapi rawan pecah. (Saran: 80-85%).</span>
                    </div>

                    <div class="form-row horizontal" style="margin-top:10px;">
                        <div>
                            <label>Auto-Resize Foto Raksasa</label>
                            <span class="form-desc" style="display:block;">Potong resolusi HP/Kamera raksasa sebelum di-convert.</span>
                        </div>
                        <input type="checkbox" name="soto_img_resize_enabled" value="1" id="cb_resize" <?php checked( $resize_enabled ); ?>>
                    </div>

                    <div class="form-row" id="resize_options" style="margin-left:20px; padding-left:15px; border-left: 2px solid #e2e8f0;">
                        <label>Maksimal Lebar Resolusi (px)</label>
                        <input type="number" name="soto_img_resize_max_width" value="<?php echo esc_attr( $max_width ); ?>" placeholder="1920">
                    </div>

                    <div class="form-row horizontal" style="margin-top:10px;">
                        <div>
                            <label style="color:#ef4444;">Simpan Mentahan Asli (Original Backup)</label>
                            <span class="form-desc" style="display:block;">Jika mati, JPG/PNG lama akan **Dihapus Permanen**. Hemat Maksimal!</span>
                        </div>
                        <input type="checkbox" name="soto_img_keep_original" value="1" <?php checked( $keep_original ); ?>>
                    </div>

                    <div style="margin-top:30px; border-top: 1px solid #f1f5f9; padding-top:20px;">
                        <button type="submit" name="soto_img_save_settings" class="btn-primary" style="width:100%;">Terapkan Engine Core</button>
                    </div>
                </form>
            </div>

            <!-- Analytics Dashboard -->
            <div class="soto-panel" style="display: flex; flex-direction: column;">
                <h2>📊 Live Performance</h2>
                <div class="chart-container">
                    <canvas id="libChart"></canvas>
                </div>
                <div class="stat-legend">
                    <div><span class="dot" style="background:#10b981;"></span>Optimized (<?php echo $optimized; ?>)</div>
                    <div><span class="dot" style="background:#ef4444;"></span>Fat/Raw (<?php echo $unoptimized; ?>)</div>
                </div>
                <div style="margin-top: auto; padding: 15px; background: #f8fafc; border-radius: 8px; text-align: center; border: 1px dashed #cbd5e1;">
                    <span style="font-size: 13px; color: #64748b;">Efisiensi Puncak Library Server Anda:</span><br>
                    <span style="font-size: 24px; font-weight: 800; color: #0f172a;"><?php echo $progress_ratio; ?>%</span>
                </div>
            </div>
            
            <!-- Bulk Converter Panel -->
            <div class="soto-panel soto-panel-full">
                <h2>🚀 Tactical Bulk Converter</h2>
                <p style="color:#64748b;">Mulai menyapu seluruhan Media Library anda yang masih menumpuk format JPG/PNG jadul. Skrip ini dirancang menggunakan AJAX antrean cerdas untuk Anti-Timeout.</p>
                
                <div style="background: #f0fdf4; border: 1px solid #bbf7d0; color: #166534; padding: 15px 20px; border-radius: 8px; margin-bottom: 25px; display:flex; justify-content:space-between; align-items:center;">
                    <span id="unconverted_count" style="font-size:15px;">Menganalisis tumpukan data media...</span>
                    <!-- The button is placed inside here for UI convenience -->
                    <button id="soto_btn_bulk" class="btn-primary" disabled>Deploy Konversi Bulk</button>
                </div>

                <div id="soto_progress_wrapper" style="display:none;">
                    <div style="display:flex; justify-content:space-between; font-size:14px; margin-bottom:8px; font-weight:700; color:#334155;">
                        <span>Memproses Index: <span id="soto_current_text">0</span> / <span id="soto_total_text">0</span></span>
                        <span id="soto_percentage" style="color:#10b981;">0%</span>
                    </div>
                    <div class="progress-box" style="display:block;">
                        <div class="progress-bar" id="soto_progress_bar"></div>
                    </div>
                    
                    <div class="log-box" id="soto_log"></div>
                </div>
            </div>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            var jq = jQuery;

            // UI Toggle Logic
            jq('#cb_resize').on('change', function(){
                if(this.checked) jq('#resize_options').slideDown();
                else jq('#resize_options').slideUp();
            }).trigger('change');

            // Chart Render
            var ctx = document.getElementById('libChart').getContext('2d');
            var libChart = new Chart(ctx, {
                type: 'doughnut',
                data: {
                    labels: ['Telah Optimasi', 'RAW/Jadul (Membebani)'],
                    datasets: [{
                        data: [<?php echo $optimized; ?>, <?php echo $unoptimized; ?>],
                        backgroundColor: ['#10b981', '#f87171'],
                        borderWidth: 0,
                        hoverOffset: 4
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    cutout: '75%',
                    plugins: {
                        legend: { display: false }
                    }
                }
            });

            // Bulk Convert Logic
            var attachment_ids = [];
            var total_ids = 0;
            var current_index = 0;
            var is_converting = false;

            function fetch_unconverted() {
                jq.post(ajaxurl, { action: 'soto_img_get_unconverted' }, function(response) {
                    if (response.success) {
                        attachment_ids = response.data.ids || [];
                        total_ids = attachment_ids.length;
                        if (total_ids > 0) {
                            jq('#unconverted_count').html('⚠️ Ditemukan <strong style="font-size:18px;">' + total_ids + '</strong> file usang (JPG/PNG) yg memakan tempat.');
                            jq('#soto_btn_bulk').prop('disabled', false);
                            jq('#soto_total_text').text(total_ids);
                        } else {
                            jq('#unconverted_count').html('🎉 Sistem Clean! Seluruh media dioptimasi penuh format Next-Gen.');
                            jq('#soto_btn_bulk').prop('disabled', true);
                        }
                    }
                });
            }

            fetch_unconverted();

            jq('#soto_btn_bulk').on('click', function() {
                if (is_converting) return;
                var ok = confirm('AWAS PENTING: Jika "Simpan Mentahan Asli" tidak dicentang, proses ini menghapus JPG lama Anda permanen. Pastikan Anda punya backup luar. Mulai penyapuan?');
                if(!ok) return;

                is_converting = true;
                jq(this).prop('disabled', true).text('Menyapu Data...').css('background', '#64748b');
                jq('#soto_progress_wrapper').slideDown();
                jq('#soto_log').show().empty();
                
                process_next_batch();
            });

            function process_next_batch() {
                if (current_index >= total_ids) {
                    finish_conversion();
                    return;
                }

                var current_id = attachment_ids[current_index];
                
                jq.ajax({
                    url: ajaxurl,
                    type: 'POST',
                    data: {
                        action: 'soto_img_bulk_step',
                        attachment_id: current_id
                    },
                    success: function(res) {
                        current_index++;
                        var perc = Math.round((current_index / total_ids) * 100);
                        
                        jq('#soto_current_text').text(current_index);
                        jq('#soto_percentage').text(perc + '%');
                        jq('#soto_progress_bar').css('width', perc + '%');
                        
                        if(res.success) {
                            jq('#soto_log').prepend('<div style="color:#059669; margin-bottom:3px;">> [SUCCESS] ID '+current_id+': '+res.data.msg+'</div>');
                        } else {
                            var errMsg = res.data || "Unknown Error";
                            jq('#soto_log').prepend('<div style="color:#ef4444; margin-bottom:3px;">> [FAILED]  ID '+current_id+': Bypass ('+errMsg+')</div>');
                        }
                        
                        process_next_batch(); // Recurse
                    },
                    error: function() {
                        jq('#soto_log').prepend('<div style="color:#ef4444; margin-bottom:3px;">> [TIMEOUT] ID '+attachment_ids[current_index]+': Server tersedak. Skip ke next file...</div>');
                        current_index++;
                        process_next_batch();
                    }
                });
            }

            function finish_conversion() {
                is_converting = false;
                jq('#soto_btn_bulk').text('Mission Accomplished').css({'background':'#10b981', 'color':'white'});
                jq('#soto_log').prepend('<div style="margin-top:10px; font-weight:bold; color:#f59e0b;">--- TACTICAL SWEEP SELESAI. SISTEM REBOOT DALAM 3 DETIK ---</div>');
                
                setTimeout(function(){ window.location.reload(); }, 3500);
            }
        });
    </script>
    <?php
}

/**
 * 3. Logika Utilitas & Konverter Worker Khusus File (Digunakan saat wp_handle_upload & AJAX bulk convert)
 */
function soto_img_perform_conversion( $file_path, $quality, $resize, $max_width, $target_format ) {
    $image_editor = wp_get_image_editor( $file_path );
    if ( is_wp_error( $image_editor ) ) return $image_editor;

    // Optional Auto-resize
    if ( $resize && $max_width > 0 ) {
        $size = $image_editor->get_size();
        if ( ! is_wp_error( $size ) && $size['width'] > $max_width ) {
            $image_editor->resize( $max_width, null, false );
        }
    }

    $image_editor->set_quality( $quality );

    $ext = ($target_format === 'avif') ? 'avif' : 'webp';
    $mime = ($target_format === 'avif') ? 'image/avif' : 'image/webp';

    $path_info = pathinfo( $file_path );
    $new_filename = wp_unique_filename( $path_info['dirname'], $path_info['filename'] . '.' . $ext );
    $new_file_path = $path_info['dirname'] . '/' . $new_filename;

    $saved = $image_editor->save( $new_file_path, $mime );
    return $saved;
}

/**
 * 4. Hook wp_handle_upload (Konversi Otomatis saat user menambah file baru di Media)
 */
function soto_img_convert_on_upload( $upload ) {
    if ( get_option( 'soto_img_enabled' ) != '1' ) return $upload;
    if ( isset( $upload['error'] ) && $upload['error'] ) return $upload;

    $supported_types = array( 'image/jpeg', 'image/png' );
    if ( ! in_array( $upload['type'], $supported_types, true ) ) return $upload;

    $file_path = $upload['file'];
    $old_size = @filesize( $file_path );

    $quality = (int) get_option( 'soto_img_quality', 85 );
    $resize = get_option( 'soto_img_resize_enabled' ) == '1';
    $max_width = (int) get_option( 'soto_img_resize_max_width', 1920 );
    $keep_original = get_option( 'soto_img_keep_original' ) == '1';
    $target_format = get_option( 'soto_img_target_format', 'webp' );

    $saved_image = soto_img_perform_conversion( $file_path, $quality, $resize, $max_width, $target_format );

    if ( ! is_wp_error( $saved_image ) ) {
        $new_size = @filesize( $saved_image['path'] );
        $mime = ($target_format === 'avif') ? 'image/avif' : 'image/webp';
        
        // Akumulasi penghematan
        if ( $old_size && $new_size ) {
            $saving = $old_size - $new_size;
            if ( $saving > 0 ) update_option( 'soto_img_total_saved_bytes', (int) get_option( 'soto_img_total_saved_bytes', 0 ) + $saving );
        }
        update_option( 'soto_img_total_converted', (int) get_option( 'soto_img_total_converted', 0 ) + 1 );

        if ( ! $keep_original && file_exists( $file_path ) ) {
            @unlink( $file_path );
        }

        $upload['file'] = $saved_image['path'];
        $upload['url'] = dirname( $upload['url'] ) . '/' . basename( $saved_image['path'] );
        $upload['type'] = $mime;
    }

    return $upload;
}
add_filter( 'wp_handle_upload', 'soto_img_convert_on_upload' );


/**
 * 5. AJAX Handlers: Hitung Gambar & Bulk Convert Satu per Satu
 */
add_action( 'wp_ajax_soto_img_get_unconverted', 'soto_img_ajax_get_unconverted' );
function soto_img_ajax_get_unconverted() {
    if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Unauthorized' );

    global $wpdb;
    $query = "SELECT ID FROM {$wpdb->posts} WHERE post_type = 'attachment' AND post_mime_type IN ('image/jpeg', 'image/png')";
    $results = $wpdb->get_col( $query );

    wp_send_json_success( array( 'ids' => $results ) );
}

add_action( 'wp_ajax_soto_img_bulk_step', 'soto_img_ajax_bulk_step' );
function soto_img_ajax_bulk_step() {
    if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Unauthorized' );

    $id = intval( $_POST['attachment_id'] );
    if ( ! $id ) wp_send_json_error( 'No ID' );

    $file_path = get_attached_file( $id );
    if ( ! $file_path || ! file_exists( $file_path ) ) {
        wp_send_json_error( 'File harddisk ghosting (tak ditemukan).' );
    }

    $mime_type = get_post_mime_type( $id );
    if ( ! in_array( $mime_type, array( 'image/jpeg', 'image/png' ) ) ) {
        wp_send_json_error( 'Sudah Teroptimasi / Bukan JPG.' );
    }

    $old_size = @filesize( $file_path );
    $quality = (int) get_option( 'soto_img_quality', 85 );
    $resize = get_option( 'soto_img_resize_enabled' ) == '1';
    $max_width = (int) get_option( 'soto_img_resize_max_width', 1920 );
    $keep_original = get_option( 'soto_img_keep_original' ) == '1';
    $target_format = get_option( 'soto_img_target_format', 'webp' );
    $target_mime = ($target_format === 'avif') ? 'image/avif' : 'image/webp';

    $saved_image = soto_img_perform_conversion( $file_path, $quality, $resize, $max_width, $target_format );
    
    if ( is_wp_error( $saved_image ) ) wp_send_json_error( $saved_image->get_error_message() );

    $new_file_path = $saved_image['path'];
    $new_size = @filesize( $new_file_path );

    // Hapus thumbnails JPG/PNG lama
    $metadata = wp_get_attachment_metadata( $id );
    if ( ! empty( $metadata['sizes'] ) ) {
        $path_info = pathinfo( $file_path );
        foreach ( $metadata['sizes'] as $size ) {
            $thumb_path = $path_info['dirname'] . '/' . $size['file'];
            if ( file_exists( $thumb_path ) ) @unlink( $thumb_path );
        }
    }

    if ( ! $keep_original ) @unlink( $file_path );

    update_attached_file( $id, $new_file_path );
    wp_update_post( array(
        'ID' => $id,
        'post_mime_type' => $target_mime,
    ));

    if ( ! function_exists('wp_generate_attachment_metadata') ) {
        require_once( ABSPATH . 'wp-admin/includes/image.php' );
    }
    $new_metadata = wp_generate_attachment_metadata( $id, $new_file_path );
    wp_update_attachment_metadata( $id, $new_metadata );

    if ( $old_size && $new_size ) {
        $saving = $old_size - $new_size;
        if ( $saving > 0 ) update_option( 'soto_img_total_saved_bytes', (int) get_option( 'soto_img_total_saved_bytes', 0 ) + $saving );
    }
    update_option( 'soto_img_total_converted', (int) get_option( 'soto_img_total_converted', 0 ) + 1 );

    $saved_kb = soto_img_format_bytes( max(0, $old_size - $new_size), 0 );
    wp_send_json_success( array( 'msg' => "Convert Ke  ".strtoupper($target_format)." Sukses! (Hemat $saved_kb)" ) );
}
