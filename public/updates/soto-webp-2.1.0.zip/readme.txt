=== Soto WebP Converter ===
Contributors: soto-converter
Tags: webp, convert, image optimization, speed, performance
Requires at least: 5.0
Tested up to: 6.4
Requires PHP: 7.4
Stable tag: 2.1.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Optimasi gambar otomatis ke format WebP di WordPress untuk performa maksimal. Menghemat penyimpanan dan mempercepat loading situs Anda tanpa ribet.

== Description ==

Soto WebP Converter adalah solusi cerdas untuk pemilik website WordPress yang ingin meningkatkan skor Core Web Vitals. Plugin ini secara otomatis mengonversi setiap gambar yang Anda unggah (JPG, PNG, GIF) ke format WebP yang sangat ringan.

Fitur Utama:
* **Otomatis:** Konversi langsung saat upload.
* **Ringan:** Tidak membebani server karena menggunakan editor internal WordPress.
* **Dashboard Statistik:** Pantau berapa banyak ruang yang berhasil Anda hemat.
* **Privasi:** Semua proses terjadi di server Anda sendiri.

== Installation ==

1. Unggah folder `soto-webp-converter` ke direktori `/wp-content/plugins/`.
2. Aktifkan plugin melalui menu 'Plugins' di WordPress.
3. Buka menu 'Soto WebP' untuk melihat statistik.

== Frequently Asked Questions ==

= Apakah plugin ini menghapus file asli? =
Ya, secara default plugin ini akan menghapus file asli setelah berhasil dikonversi ke WebP untuk menghemat ruang penyimpanan.

= Apakah browser lama didukung? =
Format WebP didukung oleh hampir semua browser modern (Chrome, Firefox, Edge, Safari). Untuk browser sangat lama, pastikan Anda memiliki fallback atau menggunakan plugin ini pada tema modern.

== Changelog ==

= 2.1.0 =
* Branding update: Menghapus label Pro untuk rilis Repository.
* Security: Implementasi escaping dan sanitization penuh.
* I18n: Menambahkan dukungan multi-bahasa dengan text domain.

= 2.0.0 =
* Initial Version.
