<?php
/**
 * Plugin Name: Soto WebP Converter (Pro)
 * Plugin URI:  https://soto.web.id
 * Description: Plugin premium untuk konversi cerdas dari JPG/PNG ke WebP secara otomatis dengan Dashboard Statistik.
 * Version:     2.1.0
 * Author:      Soto Converter
 * Author URI:  https://soto.web.id
 * License:     GPL-2.0+
 */

// Mencegah akses langsung ke file ini
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Inisialisasi Settings & Options
 */
function soto_webp_init_settings() {
    register_setting( 'soto_webp_settings', 'soto_webp_enabled' );
    register_setting( 'soto_webp_settings', 'soto_webp_total_converted' );
    register_setting( 'soto_webp_settings', 'soto_webp_total_saved_bytes' );

    // Set default if not exists
    if ( false === get_option( 'soto_webp_enabled' ) ) {
        update_option( 'soto_webp_enabled', '1' );
    }
    if ( false === get_option( 'soto_webp_total_converted' ) ) {
        update_option( 'soto_webp_total_converted', 0 );
    }
    if ( false === get_option( 'soto_webp_total_saved_bytes' ) ) {
        update_option( 'soto_webp_total_saved_bytes', 0 );
    }
}
add_action( 'admin_init', 'soto_webp_init_settings' );

/**
 * Fungsi pembantu untuk memformat ukuran byte menjadi satuan yang mudah dibaca
 */
function soto_webp_format_bytes( $bytes, $precision = 2 ) {
    $units = array( 'B', 'KB', 'MB', 'GB', 'TB' );
    $bytes = max( $bytes, 0 );
    $pow = floor( ( $bytes ? log( $bytes ) : 0 ) / log( 1024 ) );
    $pow = min( $pow, count( $units ) - 1 );
    $bytes /= pow( 1024, $pow );
    return round( $bytes, $precision ) . ' ' . $units[ $pow ];
}

/**
 * Menambahkan Menu Admin
 */
function soto_webp_admin_menu() {
    add_menu_page(
        'Soto WebP Dashboard',
        'Soto WebP',
        'manage_options',
        'soto-webp',
        'soto_webp_render_dashboard',
        'dashicons-superhero',
        80
    );
}
add_action( 'admin_menu', 'soto_webp_admin_menu' );

/**
 * Render Dashboard UI dengan gaya modern
 */
function soto_webp_render_dashboard() {
    // Proses form submit jika ada (Toggle Enable/Disable)
    if ( isset( $_POST['soto_webp_toggle'] ) && check_admin_referer( 'soto_webp_action', 'soto_webp_nonce' ) ) {
        $new_status = ( get_option( 'soto_webp_enabled' ) == '1' ) ? '0' : '1';
        update_option( 'soto_webp_enabled', $new_status );
        echo '<div class="updated"><p>Status plugin berhasil diperbarui!</p></div>';
    }

    $is_enabled = get_option( 'soto_webp_enabled' ) == '1';
    $total_files = get_option( 'soto_webp_total_converted', 0 );
    $saved_bytes = get_option( 'soto_webp_total_saved_bytes', 0 );
    ?>
    <style>
        .soto-wrap {
            margin: 20px 20px 0 0;
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen-Sans, Ubuntu, Cantarell, "Helvetica Neue", sans-serif;
        }
        .soto-header {
            background: linear-gradient(135deg, #FF6B6B 0%, #FF8E53 100%);
            padding: 40px;
            border-radius: 15px;
            color: white;
            box-shadow: 0 10px 30px rgba(255, 107, 107, 0.3);
            margin-bottom: 30px;
        }
        .soto-header h1 { color: white; margin: 0; font-weight: 800; font-size: 2.5em; text-shadow: 2px 2px 4px rgba(0,0,0,0.1); }
        .soto-header p { font-size: 1.1em; opacity: 0.9; margin-top: 10px; }
        
        .soto-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 20px; }
        .soto-card {
            background: white;
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.05);
            transition: transform 0.3s ease;
            position: relative;
            overflow: hidden;
        }
        .soto-card:hover { transform: translateY(-5px); }
        .soto-card h3 { margin: 0; color: #666; font-size: 0.9em; text-transform: uppercase; letter-spacing: 1px; }
        .soto-card .value { font-size: 2.5em; font-weight: 700; color: #333; margin: 15px 0; display: block; }
        .soto-card .icon { position: absolute; right: 20px; bottom: 20px; font-size: 4em; opacity: 0.05; color: #333; }

        .soto-action-box {
            margin-top: 30px;
            background: #fff;
            padding: 30px;
            border-radius: 15px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            box-shadow: 0 5px 15px rgba(0,0,0,0.05);
        }
        .status-badge {
            padding: 8px 16px;
            border-radius: 50px;
            font-weight: 600;
            font-size: 0.9em;
        }
        .status-active { background: #e6fffa; color: #2d6a4f; }
        .status-disabled { background: #fff5f5; color: #c53030; }

        .btn-toggle {
            padding: 12px 24px;
            border: none;
            border-radius: 10px;
            color: white;
            font-weight: 600;
            cursor: pointer;
            transition: background 0.3s;
            text-decoration: none;
        }
        .btn-off { background: #e53e3e; }
        .btn-off:hover { background: #c53030; }
        .btn-on { background: #48bb78; }
        .btn-on:hover { background: #38a169; }

        .soto-footer { margin-top: 50px; text-align: center; color: #999; font-size: 0.9em; }
        .soto-footer a { color: #FF6B6B; text-decoration: none; font-weight: 600; }
    </style>

    <div class="soto-wrap">
        <div class="soto-header">
            <h1>Soto Converter Dashboard</h1>
            <p>Optimasi gambar otomatis untuk performa website yang gila-gilaan!</p>
        </div>

        <div class="soto-grid">
            <div class="soto-card">
                <h3>Total Konversi</h3>
                <span class="value"><?php echo number_format($total_files); ?></span>
                <span class="icon dashicons dashicons-images-alt2"></span>
            </div>
            <div class="soto-card">
                <h3>Penyimpanan Dihemat</h3>
                <span class="value"><?php echo soto_webp_format_bytes($saved_bytes); ?></span>
                <span class="icon dashicons dashicons-admin-settings"></span>
            </div>
            <div class="soto-card">
                <h3>Kualitas WebP</h3>
                <span class="value">85%</span>
                <span class="icon dashicons dashicons-star-filled"></span>
            </div>
        </div>

        <div class="soto-action-box">
            <div>
                <h2 style="margin:0;">Status Plugin</h2>
                <p style="margin:5px 0 0 0; color:#666;">
                    Aktifkan atau nonaktifkan pengonversian gambar otomatis ke format WebP.
                </p>
            </div>
            <div style="display: flex; align-items: center; gap: 20px;">
                <span class="status-badge <?php echo $is_enabled ? 'status-active' : 'status-disabled'; ?>">
                    <?php echo $is_enabled ? '● AKTIF' : '● NONAKTIF'; ?>
                </span>
                <form method="post">
                    <?php wp_nonce_field( 'soto_webp_action', 'soto_webp_nonce' ); ?>
                    <button type="submit" name="soto_webp_toggle" class="btn-toggle <?php echo $is_enabled ? 'btn-off' : 'btn-on'; ?>">
                        <?php echo $is_enabled ? 'Matikan Konversi' : 'Aktifkan Konversi'; ?>
                    </button>
                </form>
            </div>
        </div>

        <div class="soto-footer">
            Dibuat dengan ❤️ oleh <a href="https://soto.web.id" target="_blank">Soto Converter</a>. 
            Versi 2.1.0 (Pro)
        </div>
    </div>
    <?php
}

/**
 * Logika Konversi Inti
 */
function soto_convert_image_to_webp( $upload ) {
    // Jika plugin sedang di-disable di dashboard
    if ( get_option( 'soto_webp_enabled' ) != '1' ) {
        return $upload;
    }

    if ( isset( $upload['error'] ) && $upload['error'] ) {
        return $upload;
    }

    $file_path = $upload['file'];
    $file_type = $upload['type'];
    $supported_types = array( 'image/jpeg', 'image/png', 'image/gif' );

    if ( ! in_array( $file_type, $supported_types, true ) ) {
        return $upload;
    }

    // Ambil ukuran file asli
    $old_size = @filesize( $file_path );

    $image_editor = wp_get_image_editor( $file_path );
    if ( ! is_wp_error( $image_editor ) ) {
        $path_info = pathinfo( $file_path );
        $new_filename = wp_unique_filename( $path_info['dirname'], $path_info['filename'] . '.webp' );
        $new_file_path = $path_info['dirname'] . '/' . $new_filename;

        $image_editor->set_quality( 85 );
        $saved_image = $image_editor->save( $new_file_path, 'image/webp' );

        if ( ! is_wp_error( $saved_image ) ) {
            $new_size = @filesize( $new_file_path );
            
            // Hitung penghematan
            if ( $old_size && $new_size ) {
                $saved = $old_size - $new_size;
                if ( $saved > 0 ) {
                    $current_saved = (int) get_option( 'soto_webp_total_saved_bytes', 0 );
                    update_option( 'soto_webp_total_saved_bytes', $current_saved + $saved );
                }
            }

            // Update Counter
            $current_total = (int) get_option( 'soto_webp_total_converted', 0 );
            update_option( 'soto_webp_total_converted', $current_total + 1 );

            // Hapus file asli
            if ( file_exists( $file_path ) ) {
                @unlink( $file_path );
            }

            $upload['file'] = $saved_image['path'];
            $upload['url'] = dirname( $upload['url'] ) . '/' . basename( $saved_image['path'] );
            $upload['type'] = 'image/webp';
        }
    }

    return $upload;
}
add_filter( 'wp_handle_upload', 'soto_convert_image_to_webp' );

/**
 * Fitur Auto-Update untuk Soto WebP Converter (Pro)
 * Menangani pengecekan update dari server eksternal.
 */
class Soto_WebP_Updater {

	public $plugin_slug;
	public $version;
	public $remote_url;

	public function __construct( $plugin_slug, $version, $remote_url ) {
		$this->plugin_slug = $plugin_slug;
		$this->version     = $version;
		$this->remote_url  = $remote_url;

		// Filter untuk mengecek update di WordPress Updates dashboard
		add_filter( 'site_transient_update_plugins', array( $this, 'check_update' ) );

		// Filter untuk menampilkan modal detail plugins (changelog, deskripsi)
		add_filter( 'plugins_api', array( $this, 'info' ), 20, 3 );
	}

	public function check_update( $transient ) {
		if ( empty( $transient->checked ) ) {
			return $transient;
		}

		// Ambil info dari remote server
		$remote_info = $this->get_remote_info();

		if ( $remote_info && version_compare( $this->version, $remote_info->version, '<' ) ) {
			$obj              = new stdClass();
			$obj->slug        = $this->plugin_slug;
			$obj->new_version = $remote_info->version;
			$obj->package     = $remote_info->download_url;
			$obj->url         = $this->remote_url;

			$transient->response[ $this->plugin_slug . '/soto-webp-converter.php' ] = $obj;
		}

		return $transient;
	}

	public function info( $res, $action, $args ) {
		// Pastikan kita menangani plugin kita sendiri
		if ( 'plugin_information' !== $action || $args->slug !== $this->plugin_slug ) {
			return $res;
		}

		$remote_info = $this->get_remote_info();

		if ( ! $remote_info ) {
			return $res;
		}

		$res = new stdClass();
		$res->name           = $remote_info->name;
		$res->slug           = $this->plugin_slug;
		$res->version        = $remote_info->version;
		$res->download_link  = $remote_info->download_url;
		$res->sections       = (array) $remote_info->sections;
		$res->last_updated   = isset( $remote_info->last_updated ) ? $remote_info->last_updated : date( 'Y-m-d H:i:s' );

		return $res;
	}

	private function get_remote_info() {
		$request = wp_remote_get( $this->remote_url, array(
			'timeout' => 15,
			'headers' => array(
				'Accept' => 'application/json',
			),
		) );

		if ( is_wp_error( $request ) || 200 !== wp_remote_retrieve_response_code( $request ) ) {
			return false;
		}

		return json_decode( wp_remote_retrieve_body( $request ) );
	}
}

// Inisialisasi Updater
new Soto_WebP_Updater( 
	'soto-webp-converter', 
	'2.1.0', 
	'https://soto.web.id/updates/soto-webp.json' 
);
